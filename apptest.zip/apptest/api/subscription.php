<?php

include_once('../Db.php');
$db = new Db();
include_once('CheckAuthentication.php');
$checkAuth = new CheckAuthentication();

$invalid_keys = array(
    'select', 'delete', 'sleep', 'insert', 'update', 'DELETE', 'SLEEP', 'INSERT', 'UPDATE', 'where', 'WHERE', 'TRUNCATE', 'DROP', 'truncate', 'drop'
);

$requestString = file_get_contents('php://input');

//$key = md5(microtime() . rand(1000, 9999));

$_param = json_decode($requestString, true);

$user_id = $_param['user_id'];
$auth_key = $_param['auth_key'];
$action_type = $_param['action_type'];
$authentic_user = $checkAuth->requestIsAuthenticated($db, $user_id, $auth_key);  // user authentication check
if ($authentic_user) {
    if ($action_type == 'subscription_status') {
        $subscription_data = $db->get_record_by_sql("select * from subscriptions where user_id='" . $authentic_user . "' and status='1' ORDER BY id DESC LIMIT 1 ");

        if (count($subscription_data) > 0) {
            if ($subscription_data[0]['next_payment_date'] == date('Y-m-d')) {
                $response_data['subscription'] = "Enable";
                $response_data['subscription_data'] = $subscription_data;
                $message = 'Subscription available';
            } else {
                $response_data['subscription'] = "disable";
                $response_data['subscription_data'] = $subscription_data;
                $message = 'Subscription not available';
            }
            $message = 'Subscription available';
        } else {
            $message = 'No Subscription found';
            $response_data['subscription'] = "No records found";
            $response_data['subscription_data'] = $subscription_data;
        }

    }
    if ($action_type == 'subscription_submit') {
        $plan_id = $_param['plan_id'];
        $next_7days = date('Y-m-d', strtotime(' 7 day'));
        $plan_data = $db->get_record_by_sql("select * from plans where id='" . $plan_id . "' ");
        $sqlg = " INSERT INTO `subscriptions`( `user_id`,`pl_id`,`payment_date`,`next_payment_date`,`pl_rate`,`create_date`,`status`) "
            . "VALUES ('" . $authentic_user . "','" . $plan_id . "','" . date('Y-m-d') . "','" . $next_7days . "','" . $plan_data[0]['rate'] . "','" . date('Y-m-d') . "','1')";
        $db->prepare_statement($sqlg);
        $up = $db->exe_update_insert();
        if ($up > 0) {
            $response_data['subscription'] = "Plan subscription succefully done";
            $response_data['subscription_data'] = $plan_data;
            $message = 'Subscription done';
        }
    }
    $status = '1';
    
    $response_code = '200';
    $response_data = $response_data;
} else {
    $status = '0';
    $response_data = [];
    $message = 'Error Authentication Failed';
    $response_code = '400';
}

$response['status'] = $status;
$response['response_data'] = $response_data;
$response['response_message'] = $message;
$response['response_code'] = $response_code;

echo json_encode($response);
die();
