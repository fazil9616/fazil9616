<?php

error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
$in = 0;
include_once('common_functions/index.php');
include_once('../Db.php');
$db = new Db();
$img_dir = '../uploads/mntr/';

$monitor_status = $monitor_entry = $geo_tagging = $geo_image = array();
$requestString = file_get_contents('php://input');
$requestString = str_replace("'", "", $requestString);
$request_array = json_decode($requestString, true);
$mntr_status = $request_array['monitor_status'];
$mntr_entry = $request_array['monitor_entry'];
$mntr_geolocation = $request_array['mntr_geolocation'];
$status = 0;

$user_uid = $request_array["user_id"];

$check_data2 = $db->get_record_by_sql("select * from contract_monitor_user where mobile_no='" . $user_uid . "' and status='1'");
$incentive_data = array();
if (count($check_data2) > 0) {

    if (count($mntr_status) > 0) {
        foreach ($mntr_status as $glst) {
            $chk_mntr_status = $db->get_record_by_sql("select * from contract_mntr_status where contract_entry_id='" . $glst['contract_entry_id'] . "' ");
            if (count($chk_mntr_status) > 0) {
                $sqlg = " UPDATE `contract_mntr_status` SET any_delay='" . $glst['any_delay'] . "',deviation='" . $glst['deviation'] . "',observations='" . $glst['observations'] . "',status='" . $glst['status'] . "',act_status='" . $glst['act_status'] . "' where contract_entry_id='" . $glst['contract_entry_id'] . "' ";
                $db->prepare_statement($sqlg);
                $up = $db->exe_update_insert();
            } else {
                $sqlg = " INSERT INTO `contract_mntr_status`(dst_id,any_delay,deviation,facility_type,facility_id,pactivity_id,contract_entry_id,contract_id,user_id,observations,status,act_status,created_date) VALUES"
                        . " ('" . $glst['dst_id'] . "','" . $glst['any_delay'] . "','" . $glst['deviation'] . "','" . $glst['facility_type'] . "','" . $glst['facility_id'] . "','" . $glst['pactivity_id'] . "','" . $glst['contract_entry_id'] . "'"
                        . ",'" . $glst['contract_id'] . "','" . $glst['user_id'] . "','" . $glst['observations'] . "','" . $glst['status'] . "','" . $glst['act_status'] . "','" . $glst['created_date'] . "')";
                $db->prepare_statement($sqlg);
                $up = $db->exe_update_insert();
            }
            if ($up > 0) {
                $monitor_status[] = array('contract_entry_id' => $glst['contract_entry_id'], 'status' => '1');
            }
        }
    }
    if (count($mntr_geolocation) > 0) {
        foreach ($mntr_geolocation as $glst) {
            $check_geo = $db->get_record_by_sql("SELECT id,unique_id FROM contract_mntr_geolocation where unique_id='" . $glst['unique_id'] . "'");
            $image_url = '';

            if (!empty($check_geo)) {
                if (strlen($glst['image_url']) > 80) {
                    $img_str = $glst['image_url'];
                    $image_url = bmp2img2($img_str, $glst['unique_id']);
                }
                $sqlg = " UPDATE `contract_mntr_geolocation` SET `image_url`='" . $image_url . "',`lat`='" . $glst['lat'] . "',`lng`='" . $glst['lng'] . "',updated_date='" . date('Y-m-d H:i:s') . "' where unique_id ='" . $glst['unique_id'] . "' ";
                $db->prepare_statement($sqlg);
                $up = $db->exe_update_insert();
                if ($up > 0) {
                    $geo_tagging[] = array('unique_id' => $glst['unique_id'], 'image' => $image_url, 'status' => '1');
                }
            } else {
                if (strlen($glst['image_url']) > 80) {
                    $img_str = $glst['image_url'];
                    $image_url = bmp2img2($img_str, $glst['unique_id']);
                }
                $sqlg = " INSERT INTO `contract_mntr_geolocation`( `unique_id`,`contract_entry_id`,`user_id`,`lng`,`lat`,`image_url`,`created_date`,`status`) "
                        . "VALUES ('" . $glst['unique_id'] . "','" . $glst['contract_entry_id'] . "','" . $glst['user_id'] . "','" . $glst['lng'] . "','" . $glst['lat'] . "','" . $image_url . "','" . $glst['created_date'] . "','1')";
                $db->prepare_statement($sqlg);
                $up = $db->exe_update_insert();
                if ($up > 0) {
                    $geo_tagging[] = array('unique_id' => $glst['unique_id'], 'image' => $image_url, 'status' => '1');
                }
            }
        }
    }
    $entry_id = [];
    if (count($mntr_entry) > 0) {

        foreach ($mntr_entry as $glst) {
            $sqlg = " INSERT INTO `contract_mntr_entry`(comment,dst_id,facility_type,facility_id,pactivity_id,contract_entry_id,contract_id,user_id,place,width,height,length,numbers,watt,ampere,voltage,weight_kg,job,year,rmt,mts,kwp,lpd,eachs,ton,perpoint,rm,manufacturer,status,created_date) VALUES"
                    . " ('" . $glst['comment'] . "','" . $glst['dst_id'] . "','" . $glst['facility_type'] . "','" . $glst['facility_id'] . "','" . $glst['pactivity_id'] . "','" . $glst['contract_entry_id'] . "'"
                    . ",'" . $glst['contract_id'] . "','" . $glst['user_id'] . "','" . $glst['place'] . "','" . $glst['width'] . "','" . $glst['height'] . "','" . $glst['length'] . "','" . $glst['numbers'] . "','" . $glst['watt'] . "','" . $glst['ampere'] . "','" . $glst['voltage'] . "','" . $glst['weight_kg'] . "','" . $glst['job'] . "','" . $glst['year'] . "','" . $glst['rmt'] . "','" . $glst['mts'] . "','" . $glst['kwp'] . "','" . $glst['lpd'] . "','" . $glst['eachs'] . "','" . $glst['ton'] . "','" . $glst['perpoint'] . "','" . $glst['rm'] . "','" . $glst['manufacturer'] . "','" . $glst['status'] . "','" . $glst['created_date'] . "')";
            $db->prepare_statement($sqlg);
            $up = $db->exe_update_insert();
            if ($up > 0) {
                if (!in_array($glst['contract_entry_id'], $entry_id)) {
                    $entry_id[] = $glst['contract_entry_id'];
                }
            }
        }
        foreach ($entry_id as $key => $val) {
            $monitor_entry[] = array('contract_entry_id' => $val, 'status' => '1');
        }
    }
    $response = array('status' => '1', 'mntr_geolocation' => $geo_tagging, 'monitor_entry' => $monitor_entry, 'monitor_status' => $monitor_status, 'error' => '', 'message' => 'Data synced successfully');
    echo json_encode($response);
    die();
} else if (empty($check_data2)) {

    $response = array('status' => '2', 'incentive' => [], 'error' => 'BAD REQUEST', 'message' => 'Invalid user ');
    echo json_encode($response);
    die();
} else {

    $response = array('status' => '2', 'incentive' => [], 'error' => 'BAD REQUEST', 'message' => 'Invalid user ');
    echo json_encode($response);
    die();
}

function bmp2img2($data_str, $uid) {
    $img_dir2 = '../uploads/mntr/';

    $data2 = base64_decode($data_str);
    $img_name2 = $uid . ".jpg";
    if (file_put_contents($img_dir2 . $img_name2, $data2)) {
        return $img_name2;
    } else {
        return '';
    }
}
