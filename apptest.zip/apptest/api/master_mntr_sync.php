<?php

include_once('../Db.php');
$db = new Db();
include('common_functions/index.php');
include('checkAuthentication.php');

$requestString = file_get_contents('php://input');

$key = implode('-', str_split(substr(strtolower(md5(microtime() . rand(1000, 9999))), 0, 30), 6));

$requestString = str_replace('\"', '"', $requestString);
$requestString = str_replace('"{', '{', $requestString);
$requestString = str_replace('}"', '}', $requestString);

$_param = json_decode($requestString, true);

if (!isset($_param["loginJSON"])) {

    $response['status'] = 0;
    $response['response_data'] = [];
    $response['message'] = 'Technical Error';
    $response['error'] = 'Bad Request';
    echo json_encode($response);
    die;
}

$requestData = $_param["loginJSON"];

switch ($requestData["request"]) {

    case "syncData":
        $condition = " ";
        $profileCondition = " ";
        $id = trim($requestData["id"]);
        $password = $requestData["password"];
        $sqlResult = $db->get_record_by_sql("SELECT * FROM contract_monitor_user WHERE mobile_no='" . $id . "' ");

        if (count($sqlResult) > 0) {
            $blockProfileData = $sqlResult[0];
            if ($blockProfileData['status'] == 0) {
                $response['status'] = 0;
                $response['response_data'] = [];
                $response['message'] = 'Inactive User';
                $response['error'] = '';
                $response['appVersionName'] = $appVersionName;
            } else if ($blockProfileData['password'] != $password) {

                $response['status'] = 0;
                $response['response_data'] = [];
                $response['message'] = 'Invalid Credentials';
                $response['error'] = '';
                $response['appVersionName'] = $appVersionName;
            } else {
                $uid = $blockProfileData['id'];
                syncData($db, $uid);
            }
        } else {
            $response['status'] = 0;
            $response['response_data'] = [];
            $response['message'] = 'Technical Error';
            $response['error'] = 'Bad Request';
            echo json_encode($response);
            die;
        }
        break;
}

function syncData($db, $usid) {
    $pre_2days = date('Y-m-d', strtotime(' -3 day'));
    $id = $usid;
    $uid = 0;

    $sql = "SELECT cu.*,hr.dst_id FROM `contract_monitor_user` cu left join hrm_entry_summary hr on cu.user_id=hr.id where cu.id='" . $id . "'";
    $res = $db->get_record_by_sql($sql);
    $rowcount = count($res);
    if ($rowcount > 0) {
        $result = $res;
        $auth_key = '';
        $project_type = $result[0]['project_type'];
        $dst_id = $result[0]['dst_id'];
       
        $authKeyQuery = "SELECT * FROM contract_monitor_user WHERE id = '" . $id . "'";
        $recordData = $db->get_record_by_sql($authKeyQuery);
        if (count($recordData) > 0) {
            $auth_key = $recordData[0]['auth_key'];
            $uid = $recordData[0]['id'];
            
        }
        
        $result[0]['image_baseurl'] = "http://nagalandhealthproject.org/nhpcms-test/uploads/cms/";
        $sql0 = "SELECT dst_id,district_name,status,district_code_census FROM district where dst_id='$dst_id' order by district_name";
        $result0 = $db->get_record_by_sql($sql0);

        $sql1 = "SELECT blk_id,block_name,block_code_census,district_id FROM block where status = '1' and district_id='$dst_id' order by block_name ";
        $result1 = $db->get_record_by_sql($sql1);

        $sqlchc = "SELECT id,chc_name,block_id,district_id FROM chc_master where  status = '1' and district_id='$dst_id' order by chc_name";
        $resultchc = $db->get_record_by_sql($sqlchc);

        $sqlphc = "SELECT pm.id,phc_name,block_id,chc_id FROM phc_master pm left join block b on pm.block_id=b.blk_id where pm.status = '1' and district_id='$dst_id' order by phc_name ";
        $resultphc = $db->get_record_by_sql($sqlphc);

        $sql2 = "SELECT sc.id,sub_center_name,phc_id,block_id FROM `sub_center_master` sc left join block b on sc.block_id=b.blk_id where sc.status = '1' and district_id='$dst_id' order by sub_center_name";
        $result2 = $db->get_record_by_sql($sql2);

        $sql4 = "SELECT id,dh_name,district_id,ddo_name,ddo_code FROM district_hospital where district_id='$dst_id' order by dh_name";
        $result4 = $db->get_record_by_sql($sql4);

        $sql5 = "SELECT * FROM contact_facility_map where  FIND_IN_SET($dst_id, dst) ";
        $result5 = $db->get_record_by_sql($sql5);

        $sql6 = "SELECT * FROM contract_details where id IN (SELECT cntrct_id FROM contact_facility_map where  FIND_IN_SET($dst_id, dst)) and category='$project_type' ";
        $result6 = $db->get_record_by_sql($sql6);

        $sql7 = "SELECT * FROM contract_activity_mntr where project IN (SELECT cntrct_id FROM contact_facility_map where  FIND_IN_SET($dst_id, `dst`)) ";
        $result7 = $db->get_record_by_sql($sql7);

        $sql8 = "SELECT id,project_name,project_type FROM projects where status='1' ";
        $result8 = $db->get_record_by_sql($sql8);

        $sql18 = "SELECT id,activity_typename,project_type FROM activity_type ";
        $result18 = $db->get_record_by_sql($sql18);

        $sql28 = "SELECT id,activity_name,act_type FROM contract_activity ";
        $result28 = $db->get_record_by_sql($sql28);

        $sql9 = "SELECT * FROM contract_mntr_entry where user_id = '$uid'";
        $result9 = [];

        $sql39 = "SELECT * FROM projects_activity where project IN (SELECT cntrct_id FROM contact_facility_map where  FIND_IN_SET($dst_id, dst)) ";
        $result39 = $db->get_record_by_sql($sql39);

        $sql29 = "SELECT * FROM contract_mntr_status where user_id = '$uid' ";
        $result29 = [];
        
        $sqlunit = "SELECT * FROM `contract_activity_unit`";
        $activity_unit = $db->get_record_by_sql($sqlunit);
        
        $sqlunit2 = "SELECT * FROM `activity_status`";
       	$activity_status = $db->get_record_by_sql($sqlunit2);
       
        $response_sub_data["year"] = date('Y');
        $response_sub_data["auth_key"] = $auth_key;
        if ($key == '') {
            $response_data = array("response" => $response_sub_data,'activity_status'=>$activity_status, 'activity_unit'=>$activity_unit, "activity_type" => $result18, "activity" => $result28, "userdata" => $result, "district" => $result0, "blockdata" => $result1, "chc_master" => $resultchc, "phc_master" => $resultphc, "subcenter" => $result2, "dh_master" => $result4, "monitor_master" => $result7, "monitor_entry" => $result9, "monitor_status" => $result29, "projects" => $result8, "contract_details" => $result6, "contact_facility_map" => $result5, "contract_activity" => $result39, "device_id" => $device_id);
        } else {
            $response_data = array("response" => $response_sub_data,'activity_status'=>$activity_status,'activity_unit'=>$activity_unit, "activity_type" => $result18, "activity" => $result28, "userdata" => $result, "district" => $result0, "blockdata" => $result1, "chc_master" => $resultchc, "phc_master" => $resultphc, "subcenter" => $result2, "dh_master" => $result4, "monitor_master" => $result7, "monitor_entry" => $result9, "monitor_status" => $result29, "projects" => $result8, "contract_details" => $result6, "contact_facility_map" => $result5, "contract_activity" => $result39, "device_id" => $device_id);
        }

        $response['status'] = '1';

        $response['appVersionName'] = $appVersionName;
        $response['response_data'] = $response_data;
        $response['message'] = 'Master Sync successfully';
        $response['error'] = '';
    } else {
        $response['status'] = '0';
        $response['response_data'] = [];
        $response['message'] = 'Technical Error';
        $response['error'] = '';
    }
 
    echo json_encode($response);
    die();
}
?>