<?php

require_once('../Db.php');
$db = new Db();

include('checkAuthentication.php');
require_once('../class.phpmailer.php');
$requestString = file_get_contents('php://input');

$requestString = str_replace('\"', '"', $requestString);
$requestString = str_replace('"{', '{', $requestString);
$requestString = str_replace('}"', '}', $requestString);

$_param = json_decode($requestString, true);

$block_unique_id = $_param['mobile_no'];
$password = $_param['password'];
$sqlResult = "SELECT * FROM bmw_user WHERE mobile_no = '" . $block_unique_id . "'";
$recordExists = $db->get_record_by_sql($sqlResult);
if (count($recordExists) > 0 && $password != "") {
    $recordExist = $recordExists[0];
    if (strlen($password) > 5) {
        $new_hash_pwd = hashed_pwd($password);
        if ($new_hash_pwd != $recordExist['password']) {
            $db->prepare_statement("UPDATE bmw_user SET password = '" . $new_hash_pwd . "' WHERE mobile_no = '" . $block_unique_id . "'");
            $up = $db->exe_update_insert();
            if ($up > 0) {
                $response["status"] = '1';
                $response['response_data'] = [];
                $response['message'] = 'Password has been reset successfully ';
                $response['error'] = '';
            }
        } else {
            $response["status"] = '0';
            $response['response_data'] = [];
            $response['message'] = 'New password can not be same as previouse password';
            $response['error'] = '';
        }
    } else {
        $response["status"] = 0;
        $response['response_data'] = [];
        $response['message'] = 'Password can not be less than 6 characters';
        $response['error'] = '';
    }
} else {
    $response['status'] = 0;
    $response['response_data'] = [];
    $response['message'] = 'Invalid User ';
    $response['error'] = '';
}
echo json_encode($response);
die();
?>