<?php

error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
$in = 0;
include_once('common_functions/index.php');
include_once('../Db.php');
$db = new Db();
$img_dir = '../uploads/cms/';
$imageIdname_arr = array('3' => 'image_1', '13' => 'image_4', '15' => 'image_2', '17' => 'image_3', '23' => 'image_5');
$imageId_arr = array('3', '13', '15', '17','23');
$contract_entry = $geo_tagging = $hrm_image = $geo_image = array();
$requestString = file_get_contents('php://input');
$requestString = str_replace("'", "", $requestString);
$request_array = json_decode($requestString, true);
$status = 0;

$user_uid = $request_array["user_id"];

$check_data2 = $db->get_record_by_sql("select * from bmw_user where user_id='" . $user_uid . "' and status='1'");
$incentive_data = array();
if (count($check_data2) > 0) {
    
		$elst = $request_array;
        
            $status = 0;
            $check_data21 = $db->get_record_by_sql("select id,facility_type,facility_id from bmw_facility_profile where facility_type='" . $elst['facility_type'] . "' and facility_id='".$elst['facility_id']."'");
			if(count($check_data21)>0){
				$id= $check_data21[0]['id'];
				$updatesql = "UPDATE bmw_facility_profile SET status_consents_under_water='".$elst['status_consents_under_water']."',`lat`='".$elst['lat']."',`lng`='".$elst['lng']."',`email_id`='".$elst['email_id']."',`facility_type`='".$elst['facility_type']."',`facility_id`='".$elst['facility_id']."',`correspondence_address`='".$elst['correspondence_address']."',`facility_address`='".$elst['facility_address']."',`tel_fax_no`='".$elst['tel_fax_no']."',`website_url`='".$elst['website_url']."',`authorised_person`='".$elst['authorised_person']."',`hcf_cbmwtf_name`='".$elst['hcf_cbmwtf_name']."',`ownership_hcf_cbmwtf`='".$elst['ownership_hcf_cbmwtf']."',`status_authorisation`='".$elst['status_authorisation']."',`authorisation_number`='".$elst['authorisation_number']."',`valid_up_to`='".$elst['valid_up_to']."',`bedded_hospital_beds`='".$elst['bedded_hospital_beds']."',`non_bedded_hospital`='".$elst['non_bedded_hospital']."',`license_number`='".$elst['license_number']."',status='".$elst['status']."' WHERE id='" . $id . "'";
				$db->prepare_statement($updatesql);
				$up = $db->exe_update_insert();
				if ($up > 0) {
					$bmw_facility_profile[0]['sync']='1';
				}else{
					$bmw_facility_profile[0]['sync']='0';
				}
			}
        

    $response = array('status' => '1', 'bmw_facility_profile' => $bmw_facility_profile,'error' => '', 'message' => 'Data synced successfully');
    echo json_encode($response);
    die();
} elseif (empty($check_data2)) {

    $response = array('status' => '2', 'incentive' => [], 'error' => 'BAD REQUEST', 'message' => 'Invalid user ');
    echo json_encode($response);
    die();
}

function bmp2img($data_str, $indicator, $contract_entry_id) {
    $img_dir = '../uploads/cms/';
    $imageIdname_arr = array('3' => 'image_1', '13' => 'image_4', '15' => 'image_2', '17' => 'image_3', '23' => 'image_5');
    $imageId_arr = array('3', '13', '15', '17','23');
    $data = base64_decode($data_str);
    $img_name = $contract_entry_id . "_" . $imageIdname_arr[$indicator] . ".jpeg";
    $im = imagecreatefromstring($data);
    if ($im !== false) {
        header('Content-Type: image/png');
        imagejpeg($im, $img_dir . $img_name);
        return $img_name;
    }
}

function bmp2img2($data_str, $indicator, $uid) {
    $img_dir2 = '../uploads/geo/';
    $data2 = base64_decode($data_str);
    $img_name2 = $uid . $indicator . ".jpeg";
    $im2 = imagecreatefromstring($data2);
    if ($im2 !== false) {
        header('Content-Type: image/png');
        imagejpeg($im2, $img_dir2 . $img_name2);
        return $img_name2;
    }
}

?>
