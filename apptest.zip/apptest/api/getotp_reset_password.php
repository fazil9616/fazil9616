<?php

require_once('../Db.php');
$db = new Db();

include('checkAuthentication.php');
$requestString = file_get_contents('php://input');

$requestString = str_replace('\"', '"', $requestString);
$requestString = str_replace('"{', '{', $requestString);
$requestString = str_replace('}"', '}', $requestString);

$_param = json_decode($requestString, true);

$mobile_no = $_param['mobile_no'];
$sqlResult = "SELECT * FROM bmw_user WHERE mobile_no = '" . $mobile_no . "'";
$recordExists = $db->get_record_by_sql($sqlResult);
if (count($recordExists) > 0 && $mobile_no != "") {
    $recordExist = $recordExists[0];
    if ($mobile_no == $recordExist['mobile_no']) {
        $otp = mt_rand(1000, 9999);
        $message = "Please enter your OTP $otp for change password BMWM user.";
        $up = $db->sendsms($mobile_no, $message);
        $resp_sms = json_decode($up, true);
        if ($resp_sms['status'] > 0) {
            $response["status"] = 1;
            $response['response_data'] = [];
            $response['message'] = 'OTP sent successfully';
            $response['otp'] = $otp;
        } else {
            $response["status"] = 0;
            $response['response_data'] = [];
            $response['message'] = 'Sorry OTP sending failed';
            $response['otp'] = $otp;
        }
    } else {
        $response["status"] = 0;
        $response['response_data'] = [];
        $response['message'] = 'Please enter registered mobile no.';
        $response['error'] = '';
    }
} else {
    $response['status'] = 0;
    $response['response_data'] = [];
    $response['message'] = 'Invalid User ';
    $response['error'] = '';
}
echo json_encode($response);
die();
?>