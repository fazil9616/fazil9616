<?php
class CheckAuthentication
{

    function requestIsAuthenticated($db, $user_id, $requestAuthKey)
    {
        $record = $db->get_record_by_sql("SELECT id,auth_key,status FROM users WHERE user_id = '" . $user_id . "'");
        if ($record[0]['auth_key'] == $requestAuthKey) {
            return $record[0]['id'];
        } else {
            return 0;
        }
    }
}
