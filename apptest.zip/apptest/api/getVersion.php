<?php

require_once('../Db.php');
$db = new Db();
$requestString = file_get_contents('php://input');

$requestString = str_replace('\"', '"', $requestString);
$requestString = str_replace('"{', '{', $requestString);
$requestString = str_replace('}"', '}', $requestString);

$_param_all = json_decode($requestString, true);
$_POST=$_param_all;

if (isset($_POST['AppName']) && $_POST['AppName'] != '') {
    $check_block = $db->get_record_by_sql("select app_name,version_code from version_master where app_name='" . $_POST['AppName'] . "' and status='1'");
    if (!empty($check_block)) {
        $response["status"] = 1;
        $response['version_code'] = $check_block[0]['version_code'];
        $response['AppName'] = $check_block[0]['app_name'];
        $response['message'] = 'successfull';
        $response['error'] = '';
    } else {
        $response["status"] = 0;
        $response['response_data'] = [];
        $response['message'] = 'Sorry! no record found';
        $response['error'] = 'Empty';
    }
} else {
    $response["status"] = 0;
    $response['response_data'] = [];
    $response['message'] = 'Url Not Valid';
    $response['error'] = 'Technical Error';
}
echo json_encode($response);
die();
?>