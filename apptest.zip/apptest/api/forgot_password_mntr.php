<?php

require_once('../Db.php');
$db = new Db();

include('checkAuthentication.php');
require_once('../class.phpmailer.php');
$requestString = file_get_contents('php://input');

$requestString = str_replace('\"', '"', $requestString);
$requestString = str_replace('"{', '{', $requestString);
$requestString = str_replace('}"', '}', $requestString);

$_param = json_decode($requestString, true);
$block_unique_id = $_param['mobile_no'];
$email = $_param['email'];
$sqlResult = "SELECT * FROM bmw_user WHERE mobile_no = '" . $block_unique_id . "'";
$recordExists = $db->get_record_by_sql($sqlResult);
if (count($recordExists) > 0 && $email != "") {
$recordExist=$recordExists[0];
    if($recordExist['email'] == $email){
        $unique_id = $recordExist['user_id'];
        $new_pwd = mt_rand(100000, 999999);

        $new_hash_pwd = hashed_pwd($new_pwd);
	$db->prepare_statement("UPDATE bmw_user SET password = '".$new_hash_pwd."' WHERE user_id = '".$unique_id."' and mobile_no = '" . $block_unique_id . "'");
    	$up = $db->exe_update_insert();
        if($up>0){
            $to = $email;
            $subject = "Reset Password";
            $headers = "From: bcpmapp@gmail.com" . "\r NHP-BMW Aplication \n" .
                    "CC: bcpmapp@gmail.com";
            $message = "User id:" . $block_unique_id . "\nPassword:" . $new_pwd;
            if(mail($to, $subject, $message, "From:" . $headers)){
                $response["status"] = 1;
                $response['response_data'] = [];
                $response['message'] = 'Password has been sent to registered email ';
                $response['error'] = '';
            }else{
                $response["status"] = 0;
                $response['response_data'] = [];
                $response['message'] = 'Password sending failed to registered email ';
                $response['error'] = '';
            }
        }else{
            $response["status"] = 0;
            $response['response_data'] = [];
            $response['message'] = 'Technical Error';
            $response['error'] = mysqli_error($condmc);
        }
    }else{
        $response["status"] = 0;
        $response['response_data'] = [];
        $response['message'] = 'This email is not registered';
        $response['error'] = '';
    }
} else {
    $response['status'] = 0;
    $response['response_data'] = [];
    $response['message'] = 'Invalid User ';
    $response['error'] = '';
}
echo json_encode($response);
die();
?>