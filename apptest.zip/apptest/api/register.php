<?php

error_reporting(0);
include_once('../Db.php');
$db = new Db();
include('checkAuthentication.php');
$requestString = file_get_contents('php://input');
$my_file = '../../nhp/cron_json/master_data.json';
$master_data = json_decode(file_get_contents($my_file), 'true');
$key = implode('-', str_split(substr(strtolower(md5(microtime() . rand(1000, 9999))), 0, 30), 6));

$requestString = str_replace('\"', '"', $requestString);
$requestString = str_replace('"{', '{', $requestString);
$requestString = str_replace('}"', '}', $requestString);
$_POST = json_decode($requestString, true);

$data = [];
if ($_POST['action_type'] == 'check_mobile') {
    $otp = $dst_name='';
    $user_count = $db->get_record_by_sql("SELECT * FROM bmw_user WHERE mobile_no='" . $_POST['mobile'] . "' ");
    if (count($user_count) > 0) {
        $msg = 'Already registered';
        $status = '0';
    } else {
		if (isset($_POST['mobile']) && $_POST['mobile'] != '') {
            $mobile = $_POST['mobile'];
            $user_hr = $db->get_record_by_sql("SELECT CONCAT(`first_name` ,' ', `last_name`) as member_name,id,facility_type,facility,`block`,`mobile_number` as mobile FROM hr_employee_detail_view WHERE mobile_number='" . $mobile . "' ");

            if (count($user_hr) > 0) {
                $otp = rand(1000, 9999);
                $message = "Dear NHP member find OTP " . $otp . " for user registration. Thanks";
                $db->sendsms($mobile, $message);
                $post_at = $user_hr[0]['facility_type'];
                $dst_name = $master_data['district'][$user_hr[0]['district']];
                $blk_name = $facility_name = '';
                if ($user_hr[0]['facility_type'] == '1') {
                    $facility_type = 'District Hospital';
                    $post_at = 'dh';
                    $facility_name = $master_data['dh_master'][$user_hr[0]['facility']];
                } else if ($user_hr[0]['facility_type'] == '2') {
                    $facility_type = 'CHC';
                    $post_at = 'chc';
                    $facility_name = $master_data['chc'][$user_hr[0]['facility']];
                    $blk_name = $master_data['block'][$user_hr[0]['block']];
                } else if ($user_hr[0]['facility_type'] == '3') {
                    $facility_type = 'PHC';
                    $post_at = 'phc';
                    $facility_name = $master_data['phc'][$user_hr[0]['facility']];
                    $blk_name = $master_data['block'][$user_hr[0]['block']];
                } else if ($user_hr[0]['facility_type'] == '4') {
                    $post_at = 'sc';
                    $facility_type = 'Subcenter';
                    $facility_name = $master_data['subcenter'][$user_hr[0]['facility']];
                    $blk_name = $master_data['block'][$user_hr[0]['block']];
                }
                $post_data = array(
                    'facility_type' => $facility_type,
                    'facility_name' => $facility_name,
                    'district' => $dst_name,
                    'block' => $blk_name,
                    'otp' => $otp,
                    'mobile' => $_POST['mobile']
                );
                $msg = 'Entered OTP for mobile verification.';
                $status = '1';
            } else {
                $msg = 'Not verified for registration';
                $status = '0';
            }
        } else {
            $msg = 'Invalid mobile for registration';
            $status = '0';
        }
    }
    echo json_encode(array('status' => $status, 'message' => $msg, 'otp' => $otp, 'facility_type' => $facility_type, 'facility_name' => $facility_name, 'district' => $dst_name, 'block' => $blk_name, 'otp' => $otp,));
    die();
} else if ($_POST['action_type'] == 'update_user') {
	//$user_count = $db->get_record_by_sql("SELECT * FROM bmw_user WHERE mobile_no='" . $_POST['mobile'] . "' and `hr_id`>0 ");
   
    $user_data = [];
	$user_id = $_POST['user_id'];
	$mobile_no= $_POST['mobile_no'];
    $user_count = $db->get_record_by_sql("SELECT * FROM bmw_user WHERE user_id='" . $_POST['user_id'] . "' ");
    if (count($user_count) > 0) {
		
		$user_hr = $db->get_record_by_sql("SELECT id,`mobile_number` as mobile FROM hr_employee_detail_view WHERE mobile_number='" . $_POST['mobile_no'] . "' ");
	
        $hr_id = $user_hr[0]['id'];
        
        $db->prepare_statement("UPDATE `bmw_user` SET `hr_id`='" . $hr_id . "',`name`='".$_POST['name']."',`mobile_no`='".$_POST['mobile_no']."',`email`='".$_POST['email']."',updated_date='".date('Y-m-d H:i:s')."' where user_id='$user_id' ");
            $up = $db->exe_update_insert();
            if ($up > 0) {
                $user_data = $db->get_record_by_sql("SELECT * FROM bmw_user WHERE user_id='" . $_POST['user_id'] . "' ");

                    $msg = 'Updated Successfully';
                    $status = '1';
                } else {
                    $msg = 'Not Updated ';
                    $status = '0';
                }
            } else {
                $msg = 'Sorry! Invalid user';
                $status = '0';
            }
			
    echo json_encode(array('status' => $status, 'message' => $msg, 'data' => $user_data));
    die();
}
