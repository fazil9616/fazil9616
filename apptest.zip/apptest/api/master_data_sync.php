<?php

include_once('../Db.php');
$db = new Db();
include('common_functions/index.php');
include('checkAuthentication.php');

$requestString = file_get_contents('php://input');

$key = implode('-', str_split(substr(strtolower(md5(microtime() . rand(1000, 9999))), 0, 30), 6));

$requestString = str_replace('\"', '"', $requestString);
$requestString = str_replace('"{', '{', $requestString);
$requestString = str_replace('}"', '}', $requestString);

$_param = json_decode($requestString, true);

if (!isset($_param["loginJSON"])) {

    $response['status'] = 0;
    $response['response_data'] = [];
    $response['message'] = 'Technical Error';
    $response['error'] = 'Bad Request';
    echo json_encode($response);
    die;
}

$requestData = $_param["loginJSON"];

switch ($requestData["request"]) {

    case "syncData":
        if (!check_valid_user($db, trim($requestData['id']), trim($requestData['password']))) {
            $response['status'] = 0;
            $response['response_data'] = [];
            $response['message'] = 'Technical Error'.$requestData['password'];
            $response['error'] = 'BAD REQUEST';
            
            echo json_encode($response);
            die;
        }
        $condition = " ";
        $profileCondition = " ";
        syncData($db, $requestData, '', $condition, $profileCondition, $requestData["device_id"], $_param['loginJSON']['appVersionName']);
        break;
        
    case "loginData":
        $currentYear = date('Y');
        $currentMonth = date('m');
        if ($currentMonth > '3') {
            $currentFY = $currentYear . '-' . substr(($currentYear + 1), -2);
            $previousFY = ($currentYear - 1) . '-' . substr(($currentYear), -2);
        } else if ($currentMonth < '4') {
            $currentFY = ($currentYear - 1) . '-' . substr($currentYear, -2);
            $previousFY = ($currentYear - 2) . '-' . substr(($currentYear - 1), -2);
        }
        $condition = " AND (financial_year IN ('" . $previousFY . "','" . $currentFY . "')) ";
        $profileCondition = $condition;
        $appVersionName = $_param['loginJSON']['appVersionName'];
        loginData($db, $requestData, $key, $condition, $profileCondition, $_param['loginJSON']["device_id"], $_param['loginJSON']['appVersionName']);

        break;
}

function loginData($db, $requestData, $key, $condition, $profileCondition, $device_id, $appVersionName) {

    $id = trim($requestData["id"]);

    //$password = hashed_pwd($requestData["password"]);
    $password = $requestData["password"];
    $sqlResult = $db->get_record_by_sql("SELECT * FROM contractor WHERE user_id='" . $id . "'");

    if (count($sqlResult) > 0) {
        $blockProfileData = $sqlResult[0];

        if ($blockProfileData['password'] != $password) {

            $response['status'] = 0;
            $response['response_data'] = [];
            $response['message'] = 'Invalid Credentials';
            $response['error'] = '';
            $response['appVersionName'] = $appVersionName;
        } else {
            $updateAccessTokenSQLquery = "UPDATE contractor SET appVersionName='" . $appVersionName . "', device_id='" . $requestData['device_id'] . "',access_token='" . $requestData['access_token'] . "' WHERE user_id='" . $id . "'";
            $db->prepare_statement($updateAccessTokenSQLquery);
            $up = $db->exe_update_insert();
            if ($up > 0) {
                syncData($db, $requestData, $key, $condition, $profileCondition, $device_id, $appVersionName);
            } else {
                syncData($db, $requestData, $key, $condition, $profileCondition, $device_id, $appVersionName);
            }
        }
    } else {
        $response['status'] = 0;
        $response['response_data'] = [];
        $response['message'] = 'Invalid Credentials';
        $response['error'] = '';
        $response['appVersionName'] = $appVersionName;
        echo json_encode($response);
    }
    echo json_encode($response);
}

function syncData($db, $requestData, $key, $condition = '', $profileCondition = '', $device_id, $appVersionName) {

    $id = trim($requestData['id']);
    $uid = 0;
    $sql = "SELECT * FROM `contractor` where user_id='" . $id . "'";
    $res = $db->get_record_by_sql($sql);
    $rowcount = count($res);
    if ($rowcount > 0) {
        $result = $res;
        $auth_key = '';
        if ($key != '') {

            $updateAccessTokenSQLquery = "UPDATE contractor SET appVersionName='" . $appVersionName . "', device_id='" . $requestData['device_id'] . "',access_token='" . $requestData['access_token'] . "', auth_key='$key' WHERE user_id='" . $id . "'";
            $db->prepare_statement($updateAccessTokenSQLquery);
            $up = $db->exe_update_insert();
            if ($up > 0) {
                $updatedResult = $db->get_record_by_sql("SELECT auth_key, id FROM contractor WHERE user_id = '" . $id . "'");
                $updatedRow = $updatedResult[0];
                $auth_key = $updatedRow['auth_key'];
                $uid = $updatedRow['id'];
            } else {
                $authKeyQuery = "SELECT * FROM contractor WHERE user_id = '" . $id . "'";
                $recordData = $db->get_record_by_sql($authKeyQuery);
                if (count($recordData) > 0) {
                    $auth_key = $recordData[0]['auth_key'];
                    $uid = $recordData[0]['id'];
                }
            }
        } else {
            $authKeyQuery = "SELECT * FROM contractor WHERE user_id = '" . $id . "'";
            $recordData = $db->get_record_by_sql($authKeyQuery);
            if (count($recordData) > 0) {
                $auth_key = $recordData[0]['auth_key'];
                $uid = $recordData[0]['id'];
            }
        }
        
        $result[0]['image_baseurl'] = "http://nagalandhealthproject.org/nhpcms/uploads/cms/";
        $sql0 = "SELECT dst_id,district_name,status,district_code_census FROM district where status='1' order by district_name";
        $result0 = $db->get_record_by_sql($sql0);

        $sql1 = "SELECT blk_id,block_name,block_code_census,district_id FROM block where status = '1' order by block_name ";
        $result1 = $db->get_record_by_sql($sql1);

        $sqlchc = "SELECT id,chc_name,block_id,district_id FROM chc_master where  status = '1'  order by chc_name";
        $resultchc = $db->get_record_by_sql($sqlchc);

        $sqlphc = "SELECT id,phc_name,block_id,chc_id FROM phc_master where status = '1' order by phc_name ";
        $resultphc = $db->get_record_by_sql($sqlphc);

        $sql2 = "SELECT id,sub_center_name,phc_id,block_id FROM `sub_center_master`  where status = '1' order by sub_center_name";
        $result2 = $db->get_record_by_sql($sql2);

        $sql4 = "SELECT dh.id,dh.dh_name,dh.district_id,md.ddo_name, md.ddo_code FROM district_hospital dh left join master_ddo md on dh.ddo_id=md.id order by dh.dh_name";
        $result4 = $db->get_record_by_sql($sql4);

        $sql5 = "SELECT * FROM contractor_form where status='1' ";
        $result5 = $db->get_record_by_sql($sql5);

        $sql8 = "SELECT id,project_name,project_type FROM projects where status='1' ";
        $result8 = $db->get_record_by_sql($sql8);
        
        $sql18 = "SELECT id,activity_typename,project_type FROM activity_type where status='1' ";
        $result18 = $db->get_record_by_sql($sql18);
        
        $sql28 = "SELECT id,activity_name,act_type FROM contract_activity where status='1' ";
        $result28 = $db->get_record_by_sql($sql28);
        
        $sql9 = "SELECT * FROM contract_details where vendor_id = '$uid'";
        $result9 = $db->get_record_by_sql($sql9);
        
        $sql39 = "SELECT * FROM projects_activity where project IN (SELECT id FROM contract_details where vendor_id = '$uid') and status='1'";
        $result39 = $db->get_record_by_sql($sql39);
        
        $sql29 = "SELECT * FROM contact_facility_map where cntrct_id IN  (SELECT id FROM contract_details where vendor_id = '$uid') ";
        $result29 = $db->get_record_by_sql($sql29);
        
        $response_sub_data["year"] = date('Y');
        $response_sub_data["auth_key"] = $auth_key;
        if ($key == '') {
            $response_data = array("response" => $response_sub_data,"activity_type"=>$result18,"contract_activity"=>$result28, "userdata" => $result, "district" => $result0, "blockdata" => $result1, "chc_master" => $resultchc, "phc_master" => $resultphc, "subcenter" => $result2, "dh_master" => $result4, "contractor_form" => $result5, "projects" => $result8, "contract_details" => $result9, "contact_facility_map"=>$result29,"activity"=>$result39, "device_id" => $device_id);
        } else {
            $response_data = array("response" => $response_sub_data,"activity_type"=>$result18,"contract_activity"=>$result28, "userdata" => $result, "district" => $result0, "blockdata" => $result1, "chc_master" => $resultchc, "phc_master" => $resultphc, "subcenter" => $result2, "dh_master" => $result4, "contractor_form" => $result5, "projects" => $result8, "contract_details" => $result9, "contact_facility_map"=>$result29,"activity"=>$result39, "device_id" => $device_id);
        }
        $response['status'] = '1';

        $response['appVersionName'] = $appVersionName;
        $response['response_data'] = $response_data;
        $response['message'] = 'Masters Sync successfully';
        $response['error'] = '';
    } else {
        $response['status'] = '0';
        $response['response_data'] = [];
        $response['message'] = 'Technical Error';
        $response['error'] = '';
    }
    
    echo json_encode($response);
    die();
}

?>