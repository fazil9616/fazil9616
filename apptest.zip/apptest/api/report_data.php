<?php

include_once('../Db.php');
$db = new Db();
include('common_functions/index.php');
include('checkAuthentication.php');

$requestString = file_get_contents('php://input');

$key = implode('-', str_split(substr(strtolower(md5(microtime() . rand(1000, 9999))), 0, 30), 6));

$requestString = str_replace('\"', '"', $requestString);
$requestString = str_replace('"{', '{', $requestString);
$requestString = str_replace('}"', '}', $requestString);

$_param = json_decode($requestString, true);
//print_r($_param);

if($_param['user_id'] && $_param['password'] && $_param['get_data']){
	$user_id = $_param['user_id'];
	$password = $_param['password'];
	$get_data = $_param['get_data'];
	$month = $_param['month'];
	$year = $_param['year'];
	$fid = $_param['facility_id'];
    $ftype = $_param['facility_type'];
    
    $id = $id;
    $uid = 0;
	$appVersionName ='';
    $sql = "SELECT cu.*,hr.district as dst_id FROM `bmw_user` cu left join hr_employee_detail_view hr on cu.hr_id=hr.id where cu.emp_code='" . $user_id . "'";
	$res = $db->get_record_by_sql($sql);
    $rowcount = count($res);
    if ($rowcount > 0 && $year>0 ) {
        $error = '';
        $project_type = $result[0]['project_type'];
        $dst_id = $result[0]['dst_id'];
        $uid = $result[0]['hr_id'];
         if($get_data=='daily'){
			 if($_param['created_date']!=''){
			$sql = "SELECT * FROM bmw_".$get_data."_entry where facility_id = '$fid' and created_date='".$_param['created_date']."' and facility_type='$ftype' and year='$year'";
			$result = $db->get_record_by_sql($sql);
			 }else{
				 $error = "Please select date";
				  $result=[];
			 }
		 } elseif($get_data=='quaterly'){
			 if($_param['quarter']>0){
			$sql = "SELECT * FROM bmw_".$get_data."_entry where facility_id = '$fid' and quarter='".$_param['quarter']."' and facility_type='$ftype' and year='$year'";
			$result = $db->get_record_by_sql($sql);
			 }else{
				 $error = "Please select quarter";
				  $result=[];
			 }
		 }elseif($get_data=='monthly'){
			 if($_param['month']>0){
			$sql = "SELECT * FROM bmw_".$get_data."_entry where facility_id = '$fid' and month='".$_param['month']."' and facility_type='$ftype' and year='$year'";
			$result = $db->get_record_by_sql($sql);
			 }else{
				 $error = "Please select month";
				  $result=[];
			 }
		 } else{
			 $sql = "SELECT * FROM bmw_".$get_data."_entry where facility_id = '$fid' and facility_type='$ftype' and year='$year'";
			$result = $db->get_record_by_sql($sql);
		 }
		$response_data[] = array('bmw_'.$get_data.'_entry' => $result);
        if($error==''){
			if(count($result)>0){			
				$response['status'] = '1';
				$response['appVersionName'] = $appVersionName;
				$response['message'] = 'Successfully ';
				$response['error'] = '';
				$response['response_data'] = $response_data;
			} else{			
				$response['status'] = '0';
				$response['appVersionName'] = $appVersionName;
				$response['message'] = 'No data found!';
				$response['error'] = '';
				$response['response_data'] = $response_data;      
			}
        } else {
			
			$response['status'] = '0';
			$response['appVersionName'] = $appVersionName;
			$response['message'] = $error;
			$response['error'] = '';
			$response['response_data'] = [];
      
		}
        
    } else {
		if ($rowcount== 0 ) {
        $response[0]['status'] = '0';
        $response[0]['response_data'] = [];
        $response[0]['message'] = 'User does not exist';
        $response[0]['error'] = '2';
		} else {
        $response[0]['status'] = '0';
        $response[0]['response_data'] = [];
        $response[0]['message'] = 'year parameter is missing';
        $response[0]['error'] = '2';
		}
    }
}else{
		$response[0]['status'] = '0';
        $response[0]['response_data'] = [];
        $response[0]['message'] = 'Request parameter is not correct';
        $response[0]['error'] = '3';
}
	    
    echo json_encode($response);
    die();

?>