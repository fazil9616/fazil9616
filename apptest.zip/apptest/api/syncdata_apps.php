<?php

error_reporting(0);
date_default_timezone_set('Asia/Kolkata');
$in = 0;
include_once('common_functions/index.php');
include_once('../Db.php');
$db = new Db();
$img_dir = '../uploads/cms/';
$imageIdname_arr = array('3' => 'image_1', '13' => 'image_4', '15' => 'image_2', '17' => 'image_3', '23' => 'image_5');
$imageId_arr = array('3', '13', '15', '17','23');
$bmw_daily_entry = $bmw_monthly_entry = $bmw_yearly_entry = $bmw_quaterly_entry = array();
$requestString = file_get_contents('php://input');
$requestString = str_replace("'", "", $requestString);
$request_array = json_decode($requestString, true);
$bmw_daily_entry_set = $request_array['bmw_daily_entry'];
$bmw_monthly_entry_set = $request_array['bmw_monthly_entry'];
$bmw_yearly_entry_set = $request_array['bmw_yearly_entry'];
$bmw_quaterly_entry_set = $request_array['bmw_quaterly_entry'];
$status = 0;

$user_uid = $request_array["user_id"];

$check_data2 = $db->get_record_by_sql("select * from bmw_user where mobile_no='" . $user_uid . "' and status='1'");
$incentive_data = array();
if (count($check_data2) > 0) {
	$user_id=$check_data2[0]['user_id'];
    if (count($bmw_yearly_entry_set) > 0) {
        foreach ($bmw_yearly_entry_set as $lst) {
            $status = 0;
            $check_data21 = $db->get_record_by_sql("select id,unique_entry_id from bmw_yearly_entry where unique_entry_id='" . $lst['unique_entry_id'] . "' ");
			$image_url='';
            if (strlen($lst['minutes_meeting_held_attachment']) > 80) {
                    $img_str = $lst['minutes_meeting_held_attachment'];
                    $image_url = bmp2img2($img_str, $lst['unique_entry_id']);
                }
            if (count($check_data21) > 0) {
                    $sql1 = "UPDATE `bmw_yearly_entry` SET incinerators_capacity='" . $lst['incinerators_capacity'] . "',plasma_pyrolysis_capacity='" . $lst['plasma_pyrolysis_capacity'] . "',autoclaves_capacity='" . $lst['autoclaves_capacity'] . "',microwave_capacity='" . $lst['microwave_capacity'] . "',hydroclave_capacity='" . $lst['hydroclave_capacity'] . "',shredder_capacity='" . $lst['shredder_capacity'] . "',needle_tip_cutter_capacity='" . $lst['needle_tip_cutter_capacity'] . "',sharps_encapsulation_capacity='" . $lst['sharps_encapsulation_capacity'] . "',deep_burial_pits_capacity='" . $lst['deep_burial_pits_capacity'] . "',chemical_disinfection_capacity='" . $lst['chemical_disinfection_capacity'] . "',other_treatment_equipment_capacity='" . $lst['other_treatment_equipment_capacity'] . "',facility_type='" . $lst['facility_type'] . "',facility_id='" . $lst['facility_id'] . "',fy='" . $lst['fy'] . "',year='" . $lst['year'] . "',month='" . $lst['month'] . "',storage_size='" . $lst['storage_size'] . "',storage_capacity='" . $lst['storage_capacity'] . "',provision_onsite='" . $lst['provision_onsite'] . "',name_common_bmw='" . $lst['name_common_bmw'] . "',minutes_meeting_held='" . $lst['minutes_meeting_held'] . "',is_manual_training_avail='" . $lst['is_manual_training_avail'] . "',training_last_yr_met_standerd='" . $lst['training_last_yr_met_standerd'] . "',details_online_emission='" . $lst['details_online_emission'] . "',liquid_waste_yr_met_standerd='" . $lst['liquid_waste_yr_met_standerd'] . "',disinfection_yr_met_standerd='" . $lst['disinfection_yr_met_standerd'] . "',other_relevent_info='" . $lst['other_relevent_info'] . "', `status`='" . $lst['status'] . "',updated_date='" . date('Y-m-d H:i:s') . "' where unique_entry_id='" . $lst["unique_entry_id"] . "' ";
                    $db->prepare_statement($sql1);
                    $up = $db->exe_update_insert();
                } else {
                    $sqle = " INSERT INTO `bmw_yearly_entry`( `incinerators_capacity`, `plasma_pyrolysis_capacity`, `autoclaves_capacity`, `microwave_capacity`, `hydroclave_capacity`, `shredder_capacity`, `needle_tip_cutter_capacity`, `sharps_encapsulation_capacity`, `deep_burial_pits_capacity`, `chemical_disinfection_capacity`, `other_treatment_equipment_capacity`,`deep_burial_pits`, `is_manual_training_avail_name`, `microwave`, `hydroclave`, `needle_tip_cutter`, `other_treatment_equipment`, `plasma_pyrolysis`, `sharps_encapsulation`, `shredder`, `incinerators`,minutes_meeting_held_attachment,`user_id`,`unique_entry_id`,`facility_type`, `facility_id`, `fy`, `year`, `month`,  `storage_size`, `storage_capacity`, `provision_onsite`, `name_common_bmw`, `minutes_meeting_held`, `is_manual_training_avail`, `training_last_yr_met_standerd`, `details_online_emission`, `liquid_waste_yr_met_standerd`, `disinfection_yr_met_standerd`, `other_relevent_info`, `status`, `created_date`, `sync`, `updated_date`) 
					VALUES ('" . $lst['incinerators_capacity'] . "','" . $lst['plasma_pyrolysis_capacity'] . "','" . $lst['autoclaves_capacity'] . "','" . $lst['microwave_capacity'] . "','" . $lst['hydroclave_capacity'] . "','" . $lst['shredder_capacity'] . "','" . $lst['needle_tip_cutter_capacity'] . "','" . $lst['sharps_encapsulation_capacity'] . "','" . $lst['deep_burial_pits_capacity'] . "','" . $lst['chemical_disinfection_capacity'] . "','" . $lst['other_treatment_equipment_capacity'] . "','" . $lst['deep_burial_pits'] . "','" . $lst['is_manual_training_avail_name'] . "','" . $lst['microwave'] . "','" . $lst['hydroclave'] . "','" . $lst['needle_tip_cutter'] . "','" . $lst['other_treatment_equipment'] . "','" . $lst['plasma_pyrolysis'] . "','" . $lst['sharps_encapsulation'] . "','" . $lst['shredder'] . "','" . $lst['incinerators'] . "','" . $image_url . "','" . $lst['user_id'] . "','" . $lst['unique_entry_id'] . "','" . $lst['facility_type'] . "','" . $lst['facility_id'] . "','" . $lst['fy'] . "','" . $lst['year'] . "','" . $lst['month'] . "','" . $lst['storage_size'] . "','" . $lst['storage_capacity'] . "','" . $lst['provision_onsite'] . "','" . $lst['name_common_bmw'] . "','" . $lst['minutes_meeting_held'] . "','" . $lst['is_manual_training_avail'] . "','" . $lst['training_last_yr_met_standerd'] . "','" . $lst['details_online_emission'] . "','" . $lst['liquid_waste_yr_met_standerd'] . "','" . $lst['disinfection_yr_met_standerd'] . "','" . $lst['other_relevent_info'] . "','".$lst['status'] . "','".$lst['created_date'] . "','1','" . date('Y-m-d H:i:s') . "')";
                    $db->prepare_statement($sqle);
                    $up = $db->exe_update_insert();
                }
                if ($up > 0) {
                    $status++;
                }
            
            if ($status > 0) {
                $bmw_yearly_entry[] = array('unique_entry_id' => $lst['unique_entry_id'],'minutes_meeting_held_attachment'=> $image_url, 'sync' => '1');
            }
        }
    }
	if (count($bmw_monthly_entry_set) > 0) {
        foreach ($bmw_monthly_entry_set as $lst) {
            $status = 0;
            
            $check_data21 = $db->get_record_by_sql("select id,unique_entry_id from bmw_monthly_entry where unique_entry_id='" . $lst['unique_entry_id'] . "' ");
			$image_url='';
				if (strlen($lst['remedial_action_image']) > 80) {
                    $img_str = $lst['remedial_action_image'];
                    $image_url = bmp2img2($img_str, $lst['unique_entry_id']);
                }
				if (count($check_data21) > 0) {
                    $sql1 = "UPDATE `bmw_monthly_entry` SET facility_type='" . $lst['facility_type'] . "',facility_id='" . $lst['facility_id'] . "',fy='" . $lst['fy'] . "',year='" . $lst['year'] . "',month='" . $lst['month'] . "',incinerators='" . $lst['incinerators'] . "',plasma_pyrolysis='" . $lst['plasma_pyrolysis'] . "',autoclaves='" . $lst['autoclaves'] . "',microwave='" . $lst['microwave'] . "',hydroclave='" . $lst['hydroclave'] . "',shredder='" . $lst['shredder'] . "',needle_tip_cutter='" . $lst['needle_tip_cutter'] . "',sharps_encapsulation='" . $lst['sharps_encapsulation'] . "',deep_burial_pits='" . $lst['deep_burial_pits'] . "',chemical_disinfection='" . $lst['chemical_disinfection'] . "',other_treatment_equipment='" . $lst['other_treatment_equipment'] . "',`qty_recyclable_wastes_sold`='".$lst['qty_recyclable_wastes_sold']."', `no_vehicles_used_collection`='".$lst['no_vehicles_used_collection']."', `incineration_qty_generated`='".$lst['incineration_qty_generated']."', `incineration_where_disposed`='".$lst['incineration_where_disposed']."', `etp_qty_generated`='".$lst['etp_qty_generated']."', `etp_where_disposed`='".$lst['etp_where_disposed']."', `list_mem_hcf_not_handover`='".$lst['list_mem_hcf_not_handover']."', `no_accidents_occurred`='".$lst['no_accidents_occurred']."', `no_persons_effected`='".$lst['no_persons_effected']."', `remedial_action_taken`='".$lst['remedial_action_taken']."', `any_fatality_occurred`='".$lst['any_fatality_occurred']."', `status`='" . $lst['status'] . "',updated_date='" . date('Y-m-d H:i:s') . "' where unique_entry_id='" . $lst["unique_entry_id"] . "' ";
                    $db->prepare_statement($sql1);
                    $up = $db->exe_update_insert();
                } else {
                    $sqle = " INSERT INTO `bmw_monthly_entry`( incineration_qty_disposed,remedial_action_image,`user_id`,`unique_entry_id`,`facility_type`, `facility_id`, `fy`, `year`, `month`,  `incinerators`, `plasma_pyrolysis`, `autoclaves`, `microwave`, `hydroclave`, `shredder`, `needle_tip_cutter`, `sharps_encapsulation`, `deep_burial_pits`, `chemical_disinfection`, `other_treatment_equipment`, `qty_recyclable_wastes_sold`, `no_vehicles_used_collection`, `incineration_qty_generated`, `incineration_where_disposed`, `etp_qty_generated`, `etp_where_disposed`, `list_mem_hcf_not_handover`, `no_accidents_occurred`, `no_persons_effected`, `remedial_action_taken`, `any_fatality_occurred`, `status`, `created_date`, `sync`, `updated_date`) 
					VALUES ('" . $lst['incineration_qty_disposed'] . "','" . $image_url . "','" . $lst['user_id'] . "','" . $lst['unique_entry_id'] . "','" . $lst['facility_type'] . "','" . $lst['facility_id'] . "','" . $lst['fy'] . "','" . $lst['year'] . "','" . $lst['month'] . "','" . $lst['incinerators'] . "','" . $lst['plasma_pyrolysis'] . "','" . $lst['autoclaves'] . "','" . $lst['microwave'] . "','" . $lst['hydroclave'] . "','" . $lst['shredder'] . "','" . $lst['needle_tip_cutter'] . "','" . $lst['sharps_encapsulation'] . "','" . $lst['deep_burial_pits'] . "','" . $lst['chemical_disinfection'] . "','" . $lst['other_treatment_equipment'] . "','" . $lst['qty_recyclable_wastes_sold'] . "','" . $lst['no_vehicles_used_collection'] . "','" . $lst['incineration_qty_generated'] . "','" . $lst['incineration_where_disposed'] . "','" . $lst['etp_qty_generated'] . "','" . $lst['etp_where_disposed'] . "','" . $lst['list_mem_hcf_not_handover'] . "','" . $lst['no_accidents_occurred'] . "','" . $lst['no_persons_effected'] . "','" . $lst['remedial_action_taken'] . "','" . $lst['any_fatality_occurred'] . "','1','" . $lst['created_date'] . "','1','" . date('Y-m-d H:i:s') . "')";
                    $db->prepare_statement($sqle);
                    $up = $db->exe_update_insert();
                }
                if ($up > 0) {
                    $status++;
                }
            
            if ($status > 0) {
                $bmw_monthly_entry[] = array('unique_entry_id' => $lst['unique_entry_id'],'remedial_action_image'=> $image_url, 'sync' => '1');
            }
        }
    }

	if (count($bmw_daily_entry_set) > 0) {
        foreach ($bmw_daily_entry_set as $lst) {
            $status = 0;
            
            $check_data21 = $db->get_record_by_sql("select id,unique_entry_id from bmw_daily_entry where unique_entry_id='" . $lst['unique_entry_id'] . "' ");

            if (count($check_data21) > 0) {
                    $sql1 = "UPDATE `bmw_daily_entry` SET yellow_category='" . $lst['yellow_category'] . "',red_category='" . $lst['red_category'] . "',white_category='" . $lst['white_category'] . "',blue_category='" . $lst['blue_category'] . "',gen_solid_waste='" . $lst['gen_solid_waste'] . "',installed_treatment='" . $lst['installed_treatment'] . "',qty_biomedical_waste='" . $lst['qty_biomedical_waste'] . "',facility_type='" . $lst['facility_type'] . "',facility_id='" . $lst['facility_id'] . "',fy='" . $lst['fy'] . "',year='" . $lst['year'] . "',month='" . $lst['month'] . "',incinerators='" . $lst['incinerators'] . "',plasma_pyrolysis='" . $lst['plasma_pyrolysis'] . "',autoclaves='" . $lst['autoclaves'] . "',microwave='" . $lst['microwave'] . "',hydroclave='" . $lst['hydroclave'] . "',shredder='" . $lst['shredder'] . "',needle_tip_cutter='" . $lst['needle_tip_cutter'] . "',sharps_encapsulation='" . $lst['sharps_encapsulation'] . "',deep_burial_pits='" . $lst['deep_burial_pits'] . "',chemical_disinfection='" . $lst['chemical_disinfection'] . "',other_treatment_equipment='" . $lst['other_treatment_equipment'] . "', `status`='" . $lst['status'] . "',updated_date='" . date('Y-m-d H:i:s') . "' where unique_entry_id='" . $lst["unique_entry_id"] . "' ";
                    $db->prepare_statement($sql1);
                    $up = $db->exe_update_insert();
                } else {
                    $sqle = " INSERT INTO `bmw_daily_entry`(  `yellow_category`, `red_category`, `white_category`, `blue_category`, `gen_solid_waste`,installed_treatment,qty_biomedical_waste,`user_id`, unique_entry_id,`facility_type`, `facility_id`, `fy`, `year`, `month`, `incinerators`, `plasma_pyrolysis`, `autoclaves`, `microwave`, `hydroclave`, `shredder`, `needle_tip_cutter`, `sharps_encapsulation`, `deep_burial_pits`, `chemical_disinfection`, `other_treatment_equipment`, `status`, `created_date`, `sync`, `updated_date`) 
					VALUES ('" . $lst['yellow_category'] . "','" . $lst['red_category'] . "','" . $lst['white_category'] . "','" . $lst['blue_category'] . "','" . $lst['gen_solid_waste'] . "','" . $lst['installed_treatment'] . "','" . $lst['qty_biomedical_waste'] . "','" . $lst['user_id'] . "','" . $lst['unique_entry_id'] . "','" . $lst['facility_type'] . "','" . $lst['facility_id'] . "','" . $lst['fy'] . "','" . $lst['year'] . "','" . $lst['month'] . "','" . $lst['incinerators'] . "','" . $lst['plasma_pyrolysis'] . "','" . $lst['autoclaves'] . "','" . $lst['microwave'] . "','" . $lst['hydroclave'] . "','" . $lst['shredder'] . "','" . $lst['needle_tip_cutter'] . "','" . $lst['sharps_encapsulation'] . "','" . $lst['deep_burial_pits'] . "','" . $lst['chemical_disinfection'] . "','" . $lst['other_treatment_equipment'] . "','1','" . $lst['created_date'] . "','1','" . date('Y-m-d H:i:s') . "')";
                    $db->prepare_statement($sqle);
                    $up = $db->exe_update_insert();
                }
                if ($up > 0) {
                    $status++;
                }
            
            if ($status > 0) {
                $bmw_daily_entry[] = array('unique_entry_id' => $lst['unique_entry_id'], 'sync' => '1');
            }
        }
    }
	if (count($bmw_quaterly_entry_set) > 0) {
        foreach ($bmw_quaterly_entry_set as $lst) {
            $status = 0;
            
            $check_data21 = $db->get_record_by_sql("select id,unique_entry_id from bmw_quaterly_entry where quarter='" . $lst['quarter'] . "' and year='" . $lst['year'] . "' and facility_id='".$lst['facility_id']."'");

            if (count($check_data21) > 0) {
                    $sql1 = "UPDATE `bmw_quaterly_entry` SET facility_type='" . $lst['facility_type'] . "',facility_id='" . $lst['facility_id'] . "',fy='" . $lst['fy'] . "',year='" . $lst['year'] . "',month='" . $lst['month'] . "',no_trainings_conducted_bmw='" . $lst['no_trainings_conducted_bmw'] . "',no_personnel_trained='" . $lst['no_personnel_trained'] . "',no_trained_induction='" . $lst['no_trained_induction'] . "',no_not_undergone_training='" . $lst['no_not_undergone_training'] . "',any_other_information='" . $lst['any_other_information'] . "', `status`='" . $lst['status'] . "',updated_date='" . date('Y-m-d H:i:s') . "' where unique_entry_id='" . $lst["unique_entry_id"] . "' ";
                    $db->prepare_statement($sql1);
                    $up = $db->exe_update_insert();
                } else {
                    $sqle = " INSERT INTO `bmw_quaterly_entry`( quarter,`user_id`, unique_entry_id,`facility_type`, `facility_id`, `fy`, `year`, `month`, `no_trainings_conducted_bmw`, `no_personnel_trained`, `no_trained_induction`, `no_not_undergone_training`, `any_other_information`,`status`, `created_date`, `sync`, `updated_date`) 
					VALUES ('".$lst['quarter']."','" . $lst['user_id'] . "','" . $lst['unique_entry_id'] . "','" . $lst['facility_type'] . "','" . $lst['facility_id'] . "','" . $lst['fy'] . "','" . $lst['year'] . "','" . $lst['month'] . "','" . $lst['no_trainings_conducted_bmw'] . "','" . $lst['no_personnel_trained'] . "','" . $lst['no_trained_induction'] . "','" . $lst['no_not_undergone_training'] . "','" . $lst['any_other_information'] . "','1','" . $lst['created_date'] . "','1','" . date('Y-m-d H:i:s') . "')";
                    $db->prepare_statement($sqle);
                    $up = $db->exe_update_insert();
                }
                if ($up > 0) {
                    $status++;
                }
            
            if ($status > 0) {
                $bmw_quaterly_entry[] = array('unique_entry_id' => $lst['unique_entry_id'], 'sync' => '1');
            }
        }
    }
	$response_data[] = array('bmw_daily_entry' => $bmw_daily_entry,'bmw_quaterly_entry' => $bmw_quaterly_entry, "bmw_monthly_entry" => $bmw_monthly_entry,'bmw_yearly_entry'=>$bmw_yearly_entry);
    $response = array('status' => '1','response_data'=>$response_data , 'error' => '', 'message' => 'Data synced successfully');
    echo json_encode($response);
    die();
} elseif (empty($check_data2)) {

    $response = array('status' => '2', 'response_data' => [], 'error' => 'BAD REQUEST', 'message' => 'Invalid user ');
    echo json_encode($response);
    die();
}

function bmp2img2($data_str, $uid) {
    $img_dir2 = '../uploads/bmw/';
    $data2 = base64_decode($data_str);
    $img_name2 = $uid . ".jpg";
    if (file_put_contents($img_dir2 . $img_name2, $data2)) {
        return $img_name2;
    } else {
        return '';
    }
}

?>
